temp_c = int(input("온도를 입력하시오."))

temp_f = (temp_c)*(9/5) + 32
print("섭씨{}℃=>화씨{}℉입니다".format(temp_c,temp_f))